

class Parser(object):
    def __init__(self, url):
        self.url = url

